

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <h1 class="h3 mb-2 text-gray-800 fw-bold">My Exams</h1>
        <p class="text-muted">View and attend all your available exams.</p>
    </div>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card border-0 shadow-sm h-100 position-relative overflow-hidden" style="border-radius: 16px;">
                 <!-- Status Badge Logic -->
                 <?php
                    $isActive = $exam->end_time > now() && $exam->start_time <= now();
                    $isUpcoming = $exam->start_time > now();
                    $isExpired = $exam->end_time <= now();
                    
                    $statusColor = $isActive ? 'success' : ($isUpcoming ? 'warning' : 'secondary');
                    $statusText = $isActive ? 'Active' : ($isUpcoming ? 'Upcoming' : 'Expired');
                    $borderColor = $isActive ? '#198754' : ($isUpcoming ? '#ffc107' : '#6c757d');
                 ?>

                <div class="card-body p-4 position-relative">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="badge bg-light text-primary border shadow-sm px-3 py-2 rounded-pill fw-normal">
                            <i class="bi bi-book me-1"></i> <?php echo e($exam->course->title ?? 'General'); ?>

                        </span>
                        <span class="badge bg-<?php echo e($statusColor); ?>-soft text-<?php echo e($statusColor); ?> border border-<?php echo e($statusColor); ?> rounded-pill px-3 py-1">
                            <?php echo e($statusText); ?>

                        </span>
                    </div>

                    <h5 class="fw-bold mb-2"><?php echo e($exam->title); ?></h5>
                    <p class="text-muted small mb-3 text-truncate-3" style="min-height: 40px;">
                        <?php echo e($exam->description ?? 'No description provided.'); ?>

                    </p>

                    <div class="d-flex align-items-center mb-2 text-muted small">
                        <i class="bi bi-clock me-2"></i> 
                        <span><?php echo e($exam->duration_minutes); ?> Mins</span>
                    </div>
                    
                    <div class="d-flex align-items-center mb-4 text-muted small">
                        <i class="bi bi-calendar-event me-2"></i>
                        <span>
                            <?php echo e($exam->start_time->format('M d, h:i A')); ?> - 
                            <?php echo e($exam->end_time->format('M d, h:i A')); ?>

                        </span>
                    </div>

                    <div class="d-grid">
                        <?php if($isActive): ?>
                             <a href="<?php echo e(route('student.exams.show', $exam->id)); ?>" class="btn btn-primary fw-bold shadow-sm rounded-3 py-2">
                                <i class="bi bi-play-circle me-2"></i> Attend Exam
                            </a>
                        <?php elseif($isUpcoming): ?>
                             <button disabled class="btn btn-light text-muted fw-bold shadow-sm rounded-3 py-2 border">
                                <i class="bi bi-lock me-2"></i> Starts Soon
                            </button>
                        <?php else: ?>
                             <button disabled class="btn btn-secondary fw-bold shadow-sm rounded-3 py-2">
                                <i class="bi bi-x-circle me-2"></i> Expired
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Decorative Border Left -->
                <div class="position-absolute start-0 top-0 bottom-0" style="width: 5px; background-color: <?php echo e($borderColor); ?>;"></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
             <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                 <div class="mb-3">
                     <i class="bi bi-clipboard-x display-1 text-light-gray opacity-25"></i>
                 </div>
                 <h4 class="fw-bold text-dark">No Exams Available</h4>
                 <p class="text-muted">You don't have any exams assigned to you at the moment.</p>
             </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/student/exams/index.blade.php ENDPATH**/ ?>