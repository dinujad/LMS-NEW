

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Exams</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.exams.create')); ?>" class="btn btn-sm btn-primary">
            <i class="bi bi-plus-lg"></i> New Exam
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Course</th>
                        <th>Duration</th>
                        <th>Questions</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($exam->title); ?></td>
                        <td><?php echo e($exam->course->title); ?></td>
                        <td><?php echo e($exam->duration_minutes); ?> mins</td>
                        <td><?php echo e($exam->questions_count); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($exam->is_published ? 'success' : 'secondary'); ?>">
                                <?php echo e($exam->is_published ? 'Published' : 'Draft'); ?>

                            </span>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="<?php echo e(route('admin.exams.show', $exam)); ?>" class="btn btn-outline-info" title="Manage Qs"><i class="bi bi-question-circle"></i> Questions</a>
                                <a href="<?php echo e(route('admin.exams.edit', $exam)); ?>" class="btn btn-outline-secondary" title="Edit"><i class="bi bi-pencil"></i></a>
                                <form action="<?php echo e(route('admin.exams.destroy', $exam)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this exam?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4">No exams created.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($exams->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/admin/exams/index.blade.php ENDPATH**/ ?>