

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Notices</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.notices.create')); ?>" class="btn btn-sm btn-primary">
            <i class="bi bi-plus-lg"></i> Create Notice
        </a>
    </div>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6 mb-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span class="badge bg-<?php echo e($notice->course ? 'info' : 'primary'); ?>">
                    <?php echo e($notice->course ? $notice->course->title : 'Global Notice'); ?>

                </span>
                <small class="text-muted"><?php echo e($notice->created_at->diffForHumans()); ?></small>
            </div>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($notice->title); ?></h5>
                <p class="card-text"><?php echo e($notice->content); ?></p>
                <?php if($notice->expires_at): ?>
                    <p class="card-text"><small class="text-danger">Expires: <?php echo e($notice->expires_at->format('Y-m-d')); ?></small></p>
                <?php endif; ?>
            </div>
            <div class="card-footer bg-white border-top-0 d-flex justify-content-end">
                <form action="<?php echo e(route('admin.notices.destroy', $notice)); ?>" method="POST" onsubmit="return confirm('Delete this notice?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-outline-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="alert alert-info">No notices published yet.</div>
    </div>
    <?php endif; ?>
</div>
<div class="mt-3">
    <?php echo e($notices->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/admin/notices/index.blade.php ENDPATH**/ ?>