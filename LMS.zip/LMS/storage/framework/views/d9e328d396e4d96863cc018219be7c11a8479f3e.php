

<?php $__env->startSection('content'); ?>
<div class="row pt-3 pb-2 mb-3 border-bottom">
    <div class="col-md-8">
        <h1 class="h2"><?php echo e($exam->title); ?> <small class="text-muted fs-5">(<?php echo e($exam->course->title); ?>)</small></h1>
    </div>
    <div class="col-md-4 text-md-end">
        <a href="<?php echo e(route('admin.exams.edit', $exam)); ?>" class="btn btn-sm btn-outline-primary">Edit Settings</a>
        <a href="<?php echo e(route('admin.exams.index')); ?>" class="btn btn-sm btn-outline-secondary">Back</a>
    </div>
</div>

<div class="row">
    <div class="col-md-12 mb-4">
        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Questions (<?php echo e($exam->questions->count()); ?>)</h5>
                <a href="<?php echo e(route('admin.exams.questions.create', $exam)); ?>" class="btn btn-sm btn-success">
                    <i class="bi bi-plus-lg"></i> Add Question
                </a>
            </div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>Question</th>
                            <th>Correct Ans</th>
                            <th>Marks</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e(Str::limit($question->question_text, 80)); ?></td>
                            <td><span class="badge bg-success"><?php echo e($question->correct_answer); ?></span></td>
                            <td><?php echo e($question->marks); ?></td>
                            <td class="text-end">
                                <form action="<?php echo e(route('admin.questions.destroy', $question)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Remove this question?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <p class="text-muted mb-2">No questions added yet.</p>
                                <a href="<?php echo e(route('admin.exams.questions.create', $exam)); ?>" class="btn btn-primary">Add First Question</a>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/admin/exams/show.blade.php ENDPATH**/ ?>