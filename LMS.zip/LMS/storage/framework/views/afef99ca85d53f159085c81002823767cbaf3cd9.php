

<?php $__env->startSection('content'); ?>
<style>
    body {
        background: #f0f2f5;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .login-container {
        background: #fff;
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        overflow: hidden;
        max-width: 900px;
        width: 100%;
        min-height: 550px;
    }
    .login-form-side {
        padding: 50px;
    }
    .login-welcome-side {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
        padding: 40px;
        position: relative;
    }
    .login-welcome-side::before {
        content: '';
        position: absolute;
        top: -50px;
        right: -50px;
        width: 150px;
        height: 150px;
        background: rgba(255,255,255,0.1);
        border-radius: 50%;
    }
    .login-welcome-side::after {
        content: '';
        position: absolute;
        bottom: -50px;
        left: -50px;
        width: 200px;
        height: 200px;
        background: rgba(255,255,255,0.1);
        border-radius: 50%;
    }
    .form-control {
        border-radius: 50px;
        padding: 12px 20px;
        background-color: #f7f9fc;
        border: none;
    }
    .form-control:focus {
        box-shadow: 0 0 0 3px rgba(118, 75, 162, 0.2);
        background-color: #fff;
    }
    .btn-login {
        background: linear-gradient(to right, #667eea, #764ba2);
        border: none;
        border-radius: 50px;
        padding: 12px;
        font-weight: bold;
        letter-spacing: 1px;
        width: 100%;
        color: white;
        transition: transform 0.2s;
    }
    .btn-login:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(118, 75, 162, 0.4);
        color: white;
    }
    .floating-label-group {
        position: relative;
        margin-bottom: 20px;
    }
    .floating-label-group i {
        position: absolute;
        left: 20px;
        top: 50%;
        transform: translateY(-50%);
        color: #a0a5b9;
    }
    .floating-label-group input {
        padding-left: 45px;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
         <div class="login-container row g-0">
             <!-- Left Side: Form -->
             <div class="col-md-7 login-form-side d-flex flex-column justify-content-center">
                 <div class="mb-5 text-center text-md-start">
                     <h2 class="fw-bold mb-1" style="color: #333;">Hello!</h2>
                     <p class="text-muted">Sign in to your account</p>
                 </div>

                 <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                 <?php endif; ?>
                 <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                 <?php endif; ?>

                 <form method="POST" action="<?php echo e(route('student.login')); ?>">
                    <?php echo csrf_field(); ?>
                    
                    <div class="floating-label-group">
                        <i class="bi bi-phone"></i>
                        <input id="phone" type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" required autofocus placeholder="Mobile Number">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger ms-3"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="floating-label-group">
                        <i class="bi bi-lock"></i>
                        <input id="password" type="password" class="form-control" name="password" required placeholder="Password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <small class="text-danger ms-3"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="form-check-label small text-muted" for="remember">Remember me</label>
                        </div>
                        <a href="<?php echo e(route('password.request')); ?>" class="small text-decoration-none" style="color: #764ba2;">Forgot Password?</a>
                    </div>

                    <button type="submit" class="btn btn-login mb-4">SIGN IN</button>
                    
                    <div class="text-center">
                        <span class="text-muted small">Don't have an account? </span>
                        <a href="<?php echo e(route('student.register')); ?>" class="text-decoration-none fw-bold" style="color: #667eea;">Create</a>
                    </div>
                 </form>
             </div>

             <!-- Right Side: Welcome -->
             <div class="col-md-5 login-welcome-side d-none d-md-flex">
                 <h2 class="fw-bold mb-3">Welcome Back!</h2>
                 <p class="mb-4" style="opacity: 0.9;">
                     ගිණුමට ප්‍රවේශ වීමේ ගැටලු පවතීනම්, නව ගිණුමක් සෑදීමකින් තොරව <br>071 138 4559 ඔස්සේ අපගේ කණ්ඩායම අමතා අනන්‍යතාවය තහවුරු කර නව මුරපදයක් ලබාගන්න.<br>
                     <br><br>Register වී නොමැති නම්
                     <br>Create Button ය click කරන්න.
                 </p>
                 <div style="font-size: 4rem; opacity: 0.8;">
                     <i class="bi bi-mortarboard"></i>
                 </div>
             </div>
         </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/auth/student-login.blade.php ENDPATH**/ ?>