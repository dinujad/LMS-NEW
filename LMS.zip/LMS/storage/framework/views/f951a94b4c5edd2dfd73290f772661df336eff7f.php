

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-4">
    <div>
        <h2 class="fw-bold mb-0">Courses Management</h2>
        <p class="text-muted small">Manage your courses, curriculums, and students.</p>
    </div>
    <div>
        <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary d-flex align-items-center gap-2">
            <i class="bi bi-plus-lg"></i> New Course
        </a>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-header bg-white border-0 py-3">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-light border-0"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" class="form-control bg-light border-0" placeholder="Search courses...">
                </div>
            </div>
            <div class="col-md-6 text-md-end mt-3 mt-md-0">
                <!-- Filters could go here -->
            </div>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light text-muted small text-uppercase">
                    <tr>
                        <th class="ps-4 py-3">Course</th>
                        <th class="py-3">Price</th>
                        <th class="py-3">Students</th>
                        <th class="py-3">Status</th>
                        <th class="py-3 text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="ps-4 py-3">
                            <div class="d-flex align-items-center">
                                <div class="me-3 position-relative">
                                    <?php if($course->thumbnail): ?>
                                        <img src="<?php echo e(asset('storage/' . $course->thumbnail)); ?>" alt="Thumb" class="rounded-3 object-fit-cover shadow-sm" style="width: 60px; height: 60px;">
                                    <?php else: ?>
                                        <div class="bg-soft-primary rounded-3 d-flex justify-content-center align-items-center" style="width: 60px; height: 60px;">
                                            <i class="bi bi-book fs-4"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <h6 class="mb-1 fw-bold text-dark"><?php echo e($course->title); ?></h6>
                                    <small class="text-muted d-block text-truncate" style="max-width: 250px;">
                                        <?php echo e(Str::limit($course->description, 50)); ?>

                                    </small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php if($course->price > 0): ?>
                                <span class="fw-bold text-dark">LKR <?php echo e(number_format($course->price, 2)); ?></span>
                            <?php else: ?>
                                <span class="badge bg-soft-success">Free</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <i class="bi bi-people me-2 text-muted"></i>
                                <span class="fw-bold"><?php echo e($course->students_count); ?></span>
                            </div>
                        </td>
                        <td>
                            <?php if($course->is_published): ?>
                                <span class="badge bg-soft-success px-3 py-2 rounded-pill">Published</span>
                            <?php else: ?>
                                <span class="badge bg-soft-warning px-3 py-2 rounded-pill">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-flex justify-content-end gap-2">
                                <a href="<?php echo e(route('admin.courses.show', $course)); ?>" class="btn btn-sm btn-outline-info rounded-pill px-3" title="Manage Content">
                                    <i class="bi bi-gear me-1"></i> Manage
                                </a>
                                <a href="<?php echo e(route('admin.courses.edit', $course)); ?>" class="btn btn-sm btn-light text-muted border" title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('admin.courses.destroy', $course)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this course?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-light text-danger border" title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <div class="d-flex flex-column align-items-center">
                                <div class="bg-light rounded-circle p-4 mb-3">
                                    <i class="bi bi-journal-plus fs-1 text-muted"></i>
                                </div>
                                <h6 class="text-muted mb-3">No courses found</h6>
                                <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-sm btn-primary">Create Your First Course</a>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($courses->hasPages()): ?>
    <div class="card-footer bg-white border-0 py-3">
        <?php echo e($courses->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>