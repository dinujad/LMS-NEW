

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Students Management</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.students.create')); ?>" class="btn btn-sm btn-primary">
            <i class="bi bi-person-plus"></i> Add Student
        </a>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form action="<?php echo e(route('admin.students.index')); ?>" method="GET" class="row g-3">
            <div class="col-md-10">
                <input type="text" name="search" class="form-control" placeholder="Search by ID, name, email or phone..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-outline-secondary w-100">Search</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><span class="badge bg-light text-dark border"><?php echo e($student->student_id ?? '-'); ?></span></td>
                        <td><?php echo e($student->name); ?></td>
                        <td><?php echo e($student->email); ?></td>
                        <td><?php echo e($student->phone ?? '-'); ?></td>
                        <td>
                             <span class="badge bg-<?php echo e($student->is_active ? 'success' : 'secondary'); ?>">
                                <?php echo e($student->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td><?php echo e($student->created_at->format('Y-m-d')); ?></td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <div class="btn-group">
                                <a href="<?php echo e(route('admin.students.show', $student)); ?>" class="btn btn-sm btn-outline-info" title="View Profile"><i class="bi bi-eye"></i></a>
                                <a href="<?php echo e(route('admin.students.edit', $student)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="if(confirm('Are you sure?')) document.getElementById('delete-<?php echo e($student->id); ?>').submit()"><i class="bi bi-trash"></i></button>
                            </div>
                            <form id="delete-<?php echo e($student->id); ?>" action="<?php echo e(route('admin.students.destroy', $student)); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4">No students found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($students->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/admin/students/index.blade.php ENDPATH**/ ?>