

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Header / Status -->
    <div class="col-12 mb-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4 d-flex align-items-center justify-content-between flex-wrap gap-3">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 60px; height: 60px; font-size: 24px;">
                        <?php echo e(strtoupper(substr($student->name, 0, 1))); ?>

                    </div>
                    <div>
                        <h4 class="fw-bold mb-0"><?php echo e($student->name); ?></h4>
                        <div class="text-muted small"><?php echo e($student->email); ?> | <?php echo e($student->student_id); ?></div>
                    </div>
                </div>
                
                <div class="d-flex align-items-center gap-3">
                    <div class="text-end">
                        <div class="small text-muted text-uppercase fw-bold">Current Status</div>
                        <?php if($isOnline): ?>
                            <span class="badge bg-success"><i class="bi bi-circle-fill small me-1"></i> Online Now</span>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="bi bi-moon-fill small me-1"></i> Offline</span>
                            <div class="small text-muted mt-1" style="font-size: 0.75rem;">
                                Last seen: <?php echo e($student->last_seen_at ? \Carbon\Carbon::parse($student->last_seen_at)->diffForHumans() : 'Never'); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    
                     <div class="vr mx-2"></div>
                     
                    <div class="text-end">
                         <div class="small text-muted text-uppercase fw-bold">Total Study Time</div>
                         <h4 class="fw-bold mb-0 text-primary"><?php echo e($totalHours); ?> Hours</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Personal Info -->
    <div class="col-lg-4 mb-4">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-header bg-transparent border-0 pt-4 pb-0">
                <h5 class="fw-bold"><i class="bi bi-person-badge me-2 text-primary"></i>Personal Details</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="text-muted">Phone</span>
                        <span class="fw-medium"><?php echo e($student->phone ?? '-'); ?></span>
                    </li>
                     <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="text-muted">WhatsApp</span>
                        <span class="fw-medium"><?php echo e($student->whatsapp_number ?? '-'); ?></span>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="text-muted">School</span>
                        <span class="fw-medium"><?php echo e($student->school ?? '-'); ?></span>
                    </li>
                     <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="text-muted">Exam Year</span>
                        <span class="fw-medium"><?php echo e($student->exam_year ?? '-'); ?></span>
                    </li>
                    <li class="list-group-item px-0 d-flex justify-content-between">
                        <span class="text-muted">Guardian</span>
                        <span class="fw-medium"><?php echo e($student->guardian_name ?? '-'); ?> (<?php echo e($student->guardian_phone); ?>)</span>
                    </li>
                </ul>
                <div class="mt-3">
                    <a href="<?php echo e(route('admin.students.edit', $student->id)); ?>" class="btn btn-light btn-sm w-100">Edit Profile</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Exam Performance -->
    <div class="col-lg-8 mb-4">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-header bg-transparent border-0 pt-4 pb-0 d-flex justify-content-between align-items-center">
                 <h5 class="fw-bold"><i class="bi bi-graph-up me-2 text-success"></i>Exam Performance</h5>
            </div>
            <div class="card-body">
                <?php if($allMarks->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Date</th>
                                    <th>Exam</th>
                                    <th>Type</th>
                                    <th class="text-center">Score</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $allMarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="small"><?php echo e(\Carbon\Carbon::parse($mark['date'])->format('Y-M-d')); ?></td>
                                    <td class="fw-medium"><?php echo e($mark['title']); ?></td>
                                    <td>
                                        <?php if($mark['type'] == 'Online'): ?>
                                            <span class="badge bg-info-soft text-info small">Online</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning-soft text-warning small">Physical</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center fw-bold">
                                        <?php echo e($mark['score']); ?> 
                                        <span class="text-muted small fw-normal">/ <?php echo e($mark['total_possible']); ?></span>
                                    </td>
                                    <td class="text-center">
                                         <?php $pct = floatval($mark['percentage']); ?>
                                         <?php if($pct >= 75): ?>
                                            <span class="badge bg-success">A</span>
                                         <?php elseif($pct >= 65): ?>
                                             <span class="badge bg-primary">B</span>
                                         <?php elseif($pct >= 55): ?>
                                              <span class="badge bg-secondary">C</span>
                                         <?php elseif($pct >= 35): ?>
                                               <span class="badge bg-warning text-dark">S</span>
                                         <?php else: ?>
                                               <span class="badge bg-danger">F</span>
                                         <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <p class="text-muted">No exam records found for this student.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/admin/students/show.blade.php ENDPATH**/ ?>