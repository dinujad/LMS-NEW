

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Exam Results</h1>
</div>

<div class="card mb-4">
    <div class="card-header bg-white">
        Search Student Result
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.results.index')); ?>" method="GET" class="row g-3 align-items-end">
            <div class="col-md-6">
                <label class="form-label">Select Exam</label>
                <select name="exam_id" class="form-select" required>
                    <option value="">Choose Exam...</option>
                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($exam->id); ?>" <?php echo e(request('exam_id') == $exam->id ? 'selected' : ''); ?>>
                            <?php echo e($exam->title); ?> (<?php echo e($exam->course->title ?? 'General'); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Student ID (e.g. SID1000)</label>
                <input type="text" name="student_id" class="form-control" placeholder="Enter Student ID" value="<?php echo e(request('student_id')); ?>" required>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Search Result</button>
            </div>
        </form>
    </div>
</div>

<?php if($searched): ?>
    <div class="card shadow-sm">
        <div class="card-header bg-light">
            Search Results
        </div>
        <div class="card-body">
            <?php if($attempts->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Exam</th>
                                <th>Score</th>
                                <th>Grade</th>
                                <th>Date Taken</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($attempt->user->name); ?>

                                    <br>
                                    <small class="text-muted"><?php echo e($attempt->user->student_id); ?></small>
                                </td>
                                <td><?php echo e($attempt->exam->title); ?></td>
                                <td>
                                    <h4 class="mb-0 fw-bold <?php echo e($attempt->score >= 40 ? 'text-success' : 'text-danger'); ?>">
                                        <?php echo e($attempt->score); ?>%
                                    </h4>
                                </td>
                                <td>
                                    <?php if($attempt->score >= 75): ?> <span class="badge bg-success">A</span>
                                    <?php elseif($attempt->score >= 65): ?> <span class="badge bg-primary">B</span>
                                    <?php elseif($attempt->score >= 55): ?> <span class="badge bg-info">C</span>
                                    <?php elseif($attempt->score >= 40): ?> <span class="badge bg-warning">S</span>
                                    <?php else: ?> <span class="badge bg-danger">F</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($attempt->created_at->format('Y-m-d H:i A')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-warning mb-0">
                    No results found for this Student ID in the selected Exam. 
                    <br>Make sure the Student ID is correct and the student has actually attempted this exam.
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/admin/results/index.blade.php ENDPATH**/ ?>