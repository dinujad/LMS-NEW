

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card text-center shadow-lg border-0">
            <div class="card-body p-5">
                <h1 class="card-title text-primary mb-3"><?php echo e($exam->title); ?></h1>
                <h5 class="text-muted"><?php echo e($exam->course->title); ?></h5>
                
                <hr class="my-4 w-50 mx-auto">

                <div class="row justify-content-center mb-4">
                    <div class="col-md-4">
                         <div class="p-3 bg-light rounded">
                             <i class="bi bi-clock fs-2 text-primary"></i>
                             <p class="mt-2 mb-0"><strong>Duration</strong><br><?php echo e($exam->duration_minutes); ?> Mins</p>
                         </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                             <i class="bi bi-person-workspace fs-2 text-primary"></i>
                             <p class="mt-2 mb-0"><strong>Attempts</strong><br><?php echo e($previousAttempts); ?> / <?php echo e($exam->max_attempts); ?></p>
                        </div>
                   </div>
                </div>

                <?php if($exam->description): ?>
                <div class="alert alert-info text-start">
                    <h5><i class="bi bi-info-circle me-2"></i>Instructions:</h5>
                    <?php echo e($exam->description); ?>

                </div>
                <?php endif; ?>

                <?php if($previousAttempts < $exam->max_attempts): ?>
                    <form action="<?php echo e(route('student.exams.start', $exam)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-lg px-5 shadow">Start Exam</button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-warning">
                        You have reached the maximum number of attempts for this exam.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/student/exams/show.blade.php ENDPATH**/ ?>