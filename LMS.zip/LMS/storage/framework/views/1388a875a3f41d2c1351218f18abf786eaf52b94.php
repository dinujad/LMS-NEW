

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">My Learning</h2>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $enrolledCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100 border-primary">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title text-primary"><?php echo e($course->title); ?></h5>
                <p class="card-text small text-muted">Enrolled on: <?php echo e($course->pivot->enrolled_at); ?></p>
                <div class="mt-auto">
                    <a href="<?php echo e(route('student.courses.show', $course)); ?>" class="btn btn-primary w-100">Continue Learning</a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12 text-center py-5">
        <p class="text-muted fs-5">You haven't enrolled in any courses yet.</p>
        <a href="<?php echo e(route('student.courses.index')); ?>" class="btn btn-primary mt-2">Browse Courses</a>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/student/courses/my.blade.php ENDPATH**/ ?>