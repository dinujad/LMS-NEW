

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card text-center border-0 shadow-lg">
            <div class="card-body p-5">
                <div class="mb-4">
                    <?php if($percentage >= 50): ?>
                        <i class="bi bi-trophy-fill text-warning display-1"></i>
                        <h2 class="mt-3 text-success">Great Job!</h2>
                    <?php else: ?>
                        <i class="bi bi-emoji-frown text-secondary display-1"></i>
                        <h2 class="mt-3 text-secondary">Keep Trying!</h2>
                    <?php endif; ?>
                </div>

                <h4 class="mb-1"><?php echo e($exam->title); ?></h4>
                <p class="text-muted">Result Summary</p>

                <div class="py-4 my-4 bg-light rounded">
                    <h1 class="display-3 fw-bold"><?php echo e($attempt->score); ?> <span class="fs-4 text-muted">/ <?php echo e($maxScore); ?></span></h1>
                    <p class="mb-0 fs-5 <?php echo e($percentage >= 50 ? 'text-success' : 'text-danger'); ?>"><?php echo e(number_format($percentage, 0)); ?>%</p>
                </div>

                <a href="<?php echo e(route('student.courses.show', $exam->course_id)); ?>" class="btn btn-outline-primary btn-lg">Back to Course</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/student/exams/result.blade.php ENDPATH**/ ?>