

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">Browsing All Courses</h2>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <?php if($course->thumbnail): ?>
                <img src="<?php echo e(asset('storage/' . $course->thumbnail)); ?>" class="card-img-top" alt="<?php echo e($course->title); ?>" style="height: 200px; object-fit: cover;">
            <?php else: ?>
                <div class="card-img-top bg-secondary text-white d-flex align-items-center justify-content-center" style="height: 200px;">
                    <span class="fs-1">Course</span>
                </div>
            <?php endif; ?>
            <div class="card-body d-flex flex-column">
                <h5 class="card-title"><?php echo e($course->title); ?></h5>
                <p class="card-text text-muted small"><?php echo e(Str::limit($course->description, 100)); ?></p>
                <div class="mt-auto d-flex justify-content-between align-items-center">
                    <span class="fw-bold text-primary"><?php echo e($course->price > 0 ? 'LKR '.number_format($course->price, 2) : 'Free'); ?></span>
                    <a href="<?php echo e(route('student.courses.show', $course)); ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="alert alert-info py-5 text-center">
            <h3>No courses available yet.</h3>
            <p>Please check back later.</p>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php echo e($courses->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/student/courses/index.blade.php ENDPATH**/ ?>