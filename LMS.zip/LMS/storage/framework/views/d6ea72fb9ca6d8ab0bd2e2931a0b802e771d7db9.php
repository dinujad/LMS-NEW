

<?php $__env->startSection('content'); ?>
<div class="sticky-top bg-white border-bottom py-3 mb-4 shadow-sm" style="z-index: 10;">
    <div class="container d-flex justify-content-between align-items-center">
        <h4 class="mb-0"><?php echo e($exam->title); ?></h4>
        <div class="d-flex align-items-center">
             <i class="bi bi-stopwatch fs-4 text-danger me-2"></i>
             <span id="timer" class="fs-4 fw-bold text-danger"><?php echo e($exam->duration_minutes); ?>:00</span>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-8">
        <form id="examForm" action="<?php echo e(route('student.exams.submit', ['exam' => $exam, 'attempt' => $attempt])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <?php $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-4 border-0 shadow-sm">
                <div class="card-body p-4">
                    <h5 class="card-title h6 text-muted mb-3">Question <?php echo e($index + 1); ?> <span class="float-end badge bg-light text-dark"><?php echo e($question->marks); ?> Marks</span></h5>
                    <p class="lead mb-4"><?php echo e($question->question_text); ?></p>

                    <div class="list-group">
                        <?php $__currentLoopData = ['option_1', 'option_2', 'option_3', 'option_4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="list-group-item list-group-item-action cursor-pointer">
                                <input class="form-check-input me-3" type="radio" name="q_<?php echo e($question->id); ?>" value="<?php echo e($opt); ?>">
                                <?php echo e($question->options[$opt]); ?>

                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="text-center mb-5">
                <button type="submit" class="btn btn-primary btn-lg px-5" onclick="return confirm('Are you sure you want to submit?');">Submit Answers</button>
            </div>
        </form>
    </div>
</div>

<script>
    // Simple timer logic
    let duration = <?php echo e($exam->duration_minutes); ?> * 60;
    const display = document.getElementById('timer');
    
    const timer = setInterval(function () {
        let minutes = parseInt(duration / 60, 10);
        let seconds = parseInt(duration % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + ":" + seconds;

        if (--duration < 0) {
            clearInterval(timer);
            alert('Time is up! Submitting your exam automatically.');
            document.getElementById('examForm').submit();
        }
    }, 1000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Amesha\Desktop\project\LMS\resources\views/student/exams/attempt.blade.php ENDPATH**/ ?>