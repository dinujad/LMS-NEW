@extends('layouts.app')

@section('content')
<div class="container d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="card shadow-lg border-0 rounded-4" style="max-width: 450px; width: 100%;">
        <div class="card-body p-5">
            <h3 class="fw-bold text-center mb-4" style="color: #333;">Verify OTP</h3>
            <p class="text-muted text-center mb-4">Enter the code sent to your phone.</p>

            @if(session('info'))
                <div class="alert alert-info text-center">{{ session('info') }}</div>
            @endif

            <form method="POST" action="{{ route('password.verify') }}">
                @csrf

                <div class="mb-3">
                    <label class="form-label text-muted small fw-bold">OTP Code</label>
                    <input id="otp" type="text" class="form-control form-control-lg rounded-pill bg-light border-0 px-3 text-center letter-spacing-2" name="otp" required placeholder="------" maxlength="6" style="letter-spacing: 5px; font-weight: bold;">
                    @error('otp')
                        <small class="text-danger ms-2">{{ $message }}</small>
                    @enderror
                </div>

                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-lg rounded-pill text-white fw-bold" style="background: linear-gradient(to right, #667eea, #764ba2); border: none;">
                        VERIFY
                    </button>
                </div>

                <div class="text-center mt-4">
                    <a href="{{ route('password.request') }}" class="text-decoration-none small" style="color: #667eea;">Resend Code</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
