@extends('layouts.app')

@section('content')
<div class="container d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="card shadow-lg border-0 rounded-4" style="max-width: 450px; width: 100%;">
        <div class="card-body p-5">
            <h3 class="fw-bold text-center mb-4" style="color: #333;">Reset Password</h3>
            <p class="text-muted text-center mb-4">Create a new secure password.</p>

            <form method="POST" action="{{ route('password.update') }}">
                @csrf

                <div class="mb-3">
                    <label class="form-label text-muted small fw-bold">New Password</label>
                    <input id="password" type="password" class="form-control form-control-lg rounded-pill bg-light border-0 px-3" name="password" required>
                    @error('password')
                        <small class="text-danger ms-2">{{ $message }}</small>
                    @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label text-muted small fw-bold">Confirm Password</label>
                    <input id="password-confirm" type="password" class="form-control form-control-lg rounded-pill bg-light border-0 px-3" name="password_confirmation" required>
                </div>

                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-lg rounded-pill text-white fw-bold" style="background: linear-gradient(to right, #667eea, #764ba2); border: none;">
                        UPDATE PASSWORD
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
