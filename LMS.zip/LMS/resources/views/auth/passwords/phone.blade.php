@extends('layouts.app')

@section('content')
<div class="container d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="card shadow-lg border-0 rounded-4" style="max-width: 450px; width: 100%;">
        <div class="card-body p-5">
            <h3 class="fw-bold text-center mb-4" style="color: #333;">Forgot Password?</h3>
            <p class="text-muted text-center mb-4">Enter your mobile number to receive a verification code.</p>

            <form method="POST" action="{{ route('password.email') }}">
                @csrf

                <div class="mb-3">
                    <label class="form-label text-muted small fw-bold">Mobile Number</label>
                    <input id="phone" type="text" class="form-control form-control-lg rounded-pill bg-light border-0 px-3" name="phone" value="{{ old('phone') }}" required autofocus placeholder="07xxxxxxxx">
                    @error('phone')
                        <small class="text-danger ms-2">{{ $message }}</small>
                    @enderror
                </div>

                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-lg rounded-pill text-white fw-bold" style="background: linear-gradient(to right, #667eea, #764ba2); border: none;">
                        SEND CODE
                    </button>
                </div>
                
                <div class="text-center mt-4">
                    <a href="{{ route('student.login') }}" class="text-decoration-none text-muted small"><i class="bi bi-arrow-left me-1"></i> Back to Login</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
