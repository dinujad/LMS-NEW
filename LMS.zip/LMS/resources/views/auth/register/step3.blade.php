@extends('layouts.app')

@section('content')
<style>
    body {
        background: #f0f2f5;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px 0;
    }
    .register-container {
        background: #fff;
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        overflow: hidden;
        width: 100%;
        max-width: 1000px;
    }
    .register-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 40px 20px;
        text-align: center;
        position: relative;
    }
    .register-header::before, .register-header::after {
        content: '';
        position: absolute;
        background: rgba(255,255,255,0.1);
        border-radius: 50%;
    }
    .register-header::before {
        top: -50px; left: -50px; width: 150px; height: 150px;
    }
    .register-header::after {
        bottom: -50px; right: -50px; width: 100px; height: 100px;
    }
    .form-control, .form-select {
        border-radius: 12px;
        padding: 12px 15px;
        background-color: #f7f9fc;
        border: 1px solid transparent;
        transition: all 0.3s;
    }
    .form-control:focus, .form-select:focus {
        box-shadow: 0 0 0 3px rgba(118, 75, 162, 0.1);
        background-color: #fff;
        border-color: #764ba2;
    }
    .btn-register {
        background: linear-gradient(to right, #667eea, #764ba2);
        border: none;
        border-radius: 50px;
        padding: 15px;
        font-weight: bold;
        letter-spacing: 1px;
        width: 100%;
        color: white;
        transition: transform 0.2s;
        font-size: 1.1rem;
    }
    .btn-register:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(118, 75, 162, 0.4);
        color: white;
    }
    .section-title {
        color: #764ba2;
        font-weight: bold;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid #f0f2f5;
        font-size: 1.1rem;
    }
    .form-floating > label {
        padding-left: 15px;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-12">
             <div class="register-container">
                <div class="register-header">
                    <h2 class="fw-bold mb-1">Final Step!</h2>
                    <p class="mb-0 text-white-50">Complete your profile to finish registration.<br>
                    මෙම ෆෝරමය සම්පූර්ණයෙන් පුරවා නිවැරදිව ලියාපදිංචි වන්න
                </p>
                </div>
                
                <div class="card-body p-4 p-md-5">
                    <form method="POST" action="{{ route('student.register.finish') }}">
                        @csrf
                        
                        <div class="row">
                            <!-- Personal Info -->
                            <div class="col-md-6 mb-4">
                                <h5 class="section-title"><i class="bi bi-person me-2"></i>Personal Info</h5>
                                <div class="row g-3">
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" value="{{ Session::get('register_phone') }}" disabled readonly>
                                            <label>Verified Mobile Number</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" name="name" value="{{ old('name') }}" required placeholder="Full Name">
                                            <label>Full Name</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="email" class="form-control" name="email" value="{{ old('email') }}" required placeholder="Email">
                                            <label>Email Address</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" name="whatsapp_number" placeholder="Whatsapp">
                                            <label>WhatsApp</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input type="date" class="form-control" name="dob" placeholder="DOB">
                                            <label>Date of Birth</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" name="nic" placeholder="NIC">
                                            <label>NIC Number</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Academic & Address -->
                            <div class="col-md-6 mb-4">
                                <h5 class="section-title"><i class="bi bi-mortarboard me-2"></i>Academic Information</h5>
                                <div class="row g-3">
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" name="school" placeholder="School Name">
                                            <label>School Name</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <input type="number" class="form-control" name="exam_year" placeholder="Year" min="2024" max="2030">
                                            <label>A/L Year</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-floating">
                                            <select class="form-select" name="medium">
                                                <option value="Sinhala">Sinhala</option>
                                                <option value="English">English</option>
                                               
                                            </select>
                                            <label>Medium</label>
                                        </div>
                                    </div>
                                    <h5 class="section-title"><i class="bi bi-mortarboard me-2"></i>Delivery Information - නිබන්දන එවීමට අදාල තොරතුරු</h5>
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" name="address_line_1" placeholder="Address">
                                            <label>Address / City</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control" name="district" placeholder="District">
                                            <label>District</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Guardian & Security -->
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-md-6 mb-4">
                                        <h5 class="section-title"><i class="bi bi-people me-2"></i>Guardian Info</h5>
                                        <div class="row g-3">
                                             <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input type="text" class="form-control" name="guardian_name" placeholder="Name">
                                                    <label>Guardian Name</label>
                                                </div>
                                            </div>
                                             <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input type="text" class="form-control" name="guardian_phone" placeholder="Phone">
                                                    <label>Guardian Phone</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-4">
                                        <h5 class="section-title"><i class="bi bi-shield-lock me-2"></i>Security</h5>
                                        <div class="row g-3">
                                             <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input type="password" class="form-control" name="password" required placeholder="Password">
                                                    <label>Password</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input type="password" class="form-control" name="password_confirmation" required placeholder="Confirm">
                                                    <label>Confirm Password</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4 pt-3 border-top text-center">
                             <div class="form-check d-inline-block mb-4 text-start">
                                <input class="form-check-input" type="checkbox" required id="agree">
                                <label class="form-check-label small text-muted" for="agree">
                                    I agree to the <a href="#" style="color: #764ba2;">Terms & Conditions</a> and Privacy Policy
                                </label>
                            </div>
                            <button type="submit" class="btn btn-register">
                                COMPLETE REGISTRATION <i class="bi bi-check-circle-fill ms-2"></i>
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
