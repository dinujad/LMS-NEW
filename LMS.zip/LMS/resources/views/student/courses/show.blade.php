@extends('layouts.student')

@section('content')
<style>
    /* Learning Mode Overrides */
    .sidebar { display: none !important; }
    .main-content { margin-left: 0 !important; padding: 20px; max-width: 100%; }
    .topbar .mobile-toggle { display: block !important; }
    
    /* Layout Styles */
    .learning-container { height: calc(100vh - 100px); }
    .lesson-list-col { height: 100%; overflow-y: auto; border-right: 1px solid #eee; }
    .player-col { height: 100%; overflow-y: auto; }
    
    .lesson-item { cursor: pointer; transition: all 0.2s; border-radius: 8px; margin-bottom: 8px; }
    .lesson-item:hover { background-color: #f8f9fa; }
    .lesson-item.active { background-color: rgba(118, 56, 255, 0.1); border-left: 4px solid var(--primary-color); }
    .lesson-item.active .lesson-title { color: var(--primary-color); font-weight: 700; }
    
    /* Video Wrapper */
    .video-wrapper { 
        position: relative; 
        padding-bottom: 56.25%; 
        height: 0; 
        background: #000; 
        border-radius: 12px; 
        overflow: hidden; 
        margin-bottom: 20px; 
        box-shadow: 0 4px 15px rgba(0,0,0,0.2); 
    }
    
    /* RAW IFRAME STYLING */
    .video-wrapper iframe { 
        position: absolute; 
        top: 0; 
        left: 0; 
        width: 100%; 
        height: 100%; 
        border: 0; 
        z-index: 1; /* Below mask */
    } 
    /* Watch on YT Blocker */
    .yt-blocker {
        position: absolute;
        bottom: 0;
        right: 0;
        width: 120px; /* Covers "Watch on YouTube" logo area */
        height: 48px; /* Covers bottom bar height approx */
        background: #000; /* Matches player bg */
        z-index: 15; /* Above iframe, below FS button */
        pointer-events: auto; /* Prevents clicking through */
    }

    /* Custom Fullscreen Button */
    .fs-toggle-btn {
        position: absolute;
        bottom: 8px; /* Centered in the 48px bar */
        right: 15px;
        z-index: 20; /* Above blocker */
        background: rgba(50,50,50,0.8);
        color: white;
        border: 1px solid rgba(255,255,255,0.2);
        border-radius: 4px;
        padding: 6px 14px;
        font-size: 14px;
        cursor: pointer;
        opacity: 0.9; 
        transition: all 0.2s;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    .fs-toggle-btn:hover { opacity: 1; background: #333; transform: scale(1.05); }
    
    .transparent-mask {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: calc(100% - 60px); /* Leave space for controls */
        z-index: 999; 
        background: rgba(0,0,0,0); 
        pointer-events: auto; /* Capture clicks */
    }
    
    /* Watermark Style */
    .video-watermark {
        position: absolute;
        z-index: 100;
        color: rgba(255, 255, 255, 0.25); /* Stronger as requested */
        font-size: 16px;
        font-weight: bold;
        pointer-events: none;
        user-select: none;
        white-space: nowrap;
        opacity: 0; /* Hidden by default */
        transition: opacity 1s ease-in-out; /* Smooth fade */
        text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
    }
    .video-watermark.visible {
        opacity: 1; /* relative to the color alpha */
    }

    /* Fullscreen Mask Fix */
    .video-wrapper:fullscreen .transparent-mask {
        z-index: 2147483647; 
        display: block !important;
        height: calc(100% - 60px);
    }
    
    /* Fullscreen Wrapper Fix */
    :-webkit-full-screen .video-wrapper { width: 100%; height: 100%; }
    :fullscreen .video-wrapper { width: 100%; height: 100%; }

    /* RAW IFRAME STYLING */
    .video-wrapper iframe { 
        position: absolute; 
        top: 0; 
        left: 0; 
        width: 100%; 
        height: 100%; 
        border: 0; 
        z-index: 1; /* Below mask */
    } 
    /* Watch on YT Blocker */
    .yt-blocker {
        position: absolute;
        bottom: 0;
        right: 0;
        width: 180px; /* Widened to cover both controls if needed */
        height: 50px; 
        background: #000; 
        z-index: 15; 
        pointer-events: auto; 
    }

    /* Speed Select - Separted */
    .speed-select {
        position: absolute;
        bottom: 8px; /* Aligned */
        right: 65px; /* To the left of FS button */
        z-index: 1002;
        background: rgba(50,50,50,0.9);
        color: white;
        border: 1px solid rgba(255,255,255,0.2);
        border-radius: 4px;
        padding: 4px 8px;
        font-size: 13px;
        cursor: pointer;
        outline: none;
        height: 34px; /* Fix height match */
    }
    .speed-select option { background: #333; }

    /* Custom Fullscreen Button - Separated */
    .fs-toggle-btn {
        position: absolute;
        bottom: 8px;
        right: 15px; 
        z-index: 1002;
        background: rgba(50,50,50,0.9);
        color: white;
        border: 1px solid rgba(255,255,255,0.2);
        border-radius: 4px;
        padding: 6px 14px;
        font-size: 14px;
        cursor: pointer;
        opacity: 0.9; 
        transition: all 0.2s;
        display: flex;
        align-items: center;
        height: 34px; /* Fix height match */
    }
    .fs-toggle-btn:hover { opacity: 1; background: #333; transform: scale(1.05); }
    
    /* Fullscreen Adjustments */
    .video-wrapper:fullscreen {
        padding-bottom: 0;
        height: 100%;
        display: flex; /* Fix vertical align */
        flex-direction: column;
        justify-content: center;
        background: #000;
    }
    .video-wrapper:fullscreen iframe {
        height: 100%;
    }

    /* Print Protection */
    @media print {
        body { display: none !important; }
    }
</style>

<div class="container-fluid learning-container">
    <div class="row h-100">
        <!-- Left Column: Lesson List -->
        <div class="col-lg-4 col-md-5 lesson-list-col pe-md-4">
            <div class="mb-4">
                <a href="{{ route('student.courses.my') }}" class="text-muted text-decoration-none small mb-2 d-inline-block">
                    <i class="bi bi-arrow-left"></i> Back to Courses
                </a>
                <h4 class="fw-bold">{{ $course->title }}</h4>
                <div class="progress" style="height: 6px;">
                    <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <small class="text-muted">0% Complete</small>
            </div>

            @if($isEnrolled)
            <div class="list-group list-group-flush">
                @forelse($course->tutes as $index => $tute)
                    <div class="lesson-item p-3 {{ $index === 0 ? 'active' : '' }}" 
                         onclick="playLesson(this)"
                         data-type="{{ $tute->type }}"
                         data-title="{{ $tute->title }}"
                         data-url="{{ $tute->video_url }}"
                         data-file="{{ $tute->file_path ? asset('storage/' . $tute->file_path) : '' }}">
                         
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <span class="text-muted me-3 small">{{ $index + 1 }}</span>
                                <div>
                                    <div class="lesson-title mb-1 text-dark small">{{ $tute->title }}</div>
                                    <div class="small">
                                        @if($tute->type == 'file')
                                            <span class="badge bg-soft-secondary text-secondary" style="font-size: 0.65rem;">Document</span>
                                        @elseif($tute->type == 'live_class')
                                            <span class="badge bg-soft-danger text-danger" style="font-size: 0.65rem;">Live Class</span>
                                        @else
                                            <span class="badge bg-soft-primary text-primary" style="font-size: 0.65rem;">Video</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <i class="bi bi-play-circle text-muted fs-5"></i>
                        </div>
                    </div>
                @empty
                    <div class="text-center py-5 text-muted small">No lessons available.</div>
                @endforelse
            </div>
            @endif
        </div>

        <!-- Right Column -->
        <div class="col-lg-8 col-md-7 player-col ps-md-4 pt-3 pt-md-0">
            @if($isEnrolled)
                <!-- Video Player Area -->
                <div class="video-wrapper shadow-sm" oncontextmenu="return false;">
                    
                    <!-- MASK for Right Click Protection -->
                    <div class="transparent-mask"></div>

                    <!-- Watermark -->
                    <div id="watermark" class="video-watermark">{{ Auth::user()->name }} ({{ Auth::user()->id }})</div>

                    <!-- BLOCKER for YouTube Logo -->
                    <div class="yt-blocker"></div>

                    <!-- Speed Control -->
                    <select id="videoSpeed" class="speed-select" onchange="changeVideoSpeed(this.value)" title="Playback Speed">
                        <option value="0.5">0.5x</option>
                        <option value="1" selected>1.0x</option>
                        <option value="1.25">1.25x</option>
                        <option value="1.5">1.5x</option>
                        <option value="2">2.0x</option>
                    </select>

                    <!-- Fullscreen Button -->
                    <button id="fsBtn" class="fs-toggle-btn" onclick="toggleFullscreen()" title="Fullscreen">
                        <i class="bi bi-arrows-fullscreen"></i>
                    </button>

                    <!-- RAW IFRAME - Added enablejsapi=1 for YT Speed Control -->
                    <iframe id="mainPlayer" src="" allow="autoplay; encrypted-media; picture-in-picture"></iframe>
                    
                    <div id="placeholderScreen" class="placeholder-content d-none">
                        <i class="bi bi-camera-video-off display-4 mb-3 text-muted"></i>
                        <h4 id="placeholderTitle">Select a Lesson</h4>
                        <p id="placeholderMsg" class="text-muted">Choose a lesson from the left.</p>
                        <a id="actionButton" href="#" target="_blank" class="btn btn-primary mt-3 d-none">Action</a>
                    </div>
                </div>

                <!-- Info -->
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h3 class="fw-bold mb-1" id="playingTitle">Select a Lesson</h3>
                                <p class="text-muted small mb-0" id="playingType">Course Introduction</p>
                            </div>
                            <div id="fileDownloadArea" class="d-none">
                                <a href="#" id="downloadBtn" target="_blank" class="btn btn-light border text-primary">
                                    <i class="bi bi-download me-1"></i> Download Material
                                </a>
                            </div>
                        </div>
                        <div class="text-muted small">
                            {!! nl2br(e($course->description)) !!}
                        </div>
                    </div>
                </div>
            @else
                <div class="d-flex align-items-center justify-content-center h-100 text-muted">
                    <div class="text-center">
                        <i class="bi bi-lock-fill display-1 opacity-25"></i>
                        <h3>Content Locked</h3>
                        <p>Enroll in the course to access.</p>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>

<script>
    // RAW JS Logic - Zero API Dependencies

    // Block Context Menu & Watermark
    document.addEventListener('DOMContentLoaded', function() {
        const wrapper = document.querySelector('.video-wrapper');
        const mask = document.querySelector('.transparent-mask');
        const watermark = document.getElementById('watermark');

        // 1. Block Right Click
        const blockRightClick = (e) => {
            e.preventDefault();
            return false;
        };

        if(wrapper) wrapper.addEventListener('contextmenu', blockRightClick);
        if(mask) mask.addEventListener('contextmenu', blockRightClick);
        
        // Block on Blocker too
        const blocker = document.querySelector('.yt-blocker');
        if(blocker) blocker.addEventListener('contextmenu', blockRightClick);

        // 2. Cycling Watermark (Visible/Invisible in fixed spots)
        function cycleWatermark() {
            if (!watermark || !wrapper) return;
            
            // Fixed Positions: TL, TR, BL, BR, Center
            const positions = [
                { top: '20px', left: '20px', right: 'auto', bottom: 'auto' }, // TL
                { top: '20px', right: '20px', left: 'auto', bottom: 'auto' }, // TR
                { bottom: '70px', left: '20px', top: 'auto', right: 'auto' }, // BL (Above controls)
                { bottom: '70px', right: '140px', top: 'auto', left: 'auto' }, // BR (Avoid blocker)
                { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', right: 'auto', bottom: 'auto' } // Center
            ];

            // Hide first
            watermark.classList.remove('visible');

            setTimeout(() => {
                // Move logic after hide
                const pos = positions[Math.floor(Math.random() * positions.length)];
                
                // Clear previous transform if not center
                watermark.style.transform = pos.transform || 'none';
                watermark.style.top = pos.top;
                watermark.style.left = pos.left;
                watermark.style.right = pos.right;
                watermark.style.bottom = pos.bottom;

                // Show
                watermark.classList.add('visible');

            }, 1000); // Wait 1s hidden
        }

        // Cycle every 5 seconds (1s hide + 4s show)
        setInterval(cycleWatermark, 5000);
        cycleWatermark(); // Initial

        // Load first
        const firstLesson = document.querySelector('.lesson-item');
        if(firstLesson) setTimeout(() => playLesson(firstLesson), 500);
    });

    function toggleFullscreen() {
        const wrapper = document.querySelector('.video-wrapper');
        const icon = document.querySelector('#fsBtn i');
        
        if (!document.fullscreenElement) {
            wrapper.requestFullscreen().catch(err => {
                alert(`Error attempting to enable fullscreen mode: ${err.message} (${err.name})`);
            });
            icon.classList.remove('bi-arrows-fullscreen');
            icon.classList.add('bi-fullscreen-exit');
        } else {
            document.exitFullscreen();
            icon.classList.remove('bi-fullscreen-exit');
            icon.classList.add('bi-arrows-fullscreen');
        }
    }

    function playLesson(element) {
        document.querySelectorAll('.lesson-item').forEach(e => e.classList.remove('active'));
        element.classList.add('active');

        const type = element.getAttribute('data-type');
        const url = element.getAttribute('data-url');
        const title = element.getAttribute('data-title');
        const file = element.getAttribute('data-file');

        document.getElementById('playingTitle').innerText = title;
        document.getElementById('playingType').innerText = type.replace('_',' ').toUpperCase();
        
        const player = document.getElementById('mainPlayer');
        const ph = document.getElementById('placeholderScreen');

        // File DL
        if(file) {
            document.getElementById('fileDownloadArea').classList.remove('d-none');
            document.getElementById('downloadBtn').href = file;
        } else {
             document.getElementById('fileDownloadArea').classList.add('d-none');
        }

        if(type === 'recording_class' || (type === 'video_link' && url)) {
            ph.classList.add('d-none');
            player.style.display = 'block';

            // 1. Try Vimeo
            let isVimeo = false;
            let vid = '';
            
            const vimeoMatch = url.match(/(?:vimeo\.com\/|player\.vimeo\.com\/video\/)([0-9]+)/);
            if(vimeoMatch && vimeoMatch[1]) {
                isVimeo = true;
                vid = vimeoMatch[1];
            }

            // 2. Try YouTube if not Vimeo
            if(!vid) {
                const ytMatch = url.match(/^.*(?:(?:youtu\.be\/|v\/|vi\/|u\/\w\/|embed\/|shorts\/)|(?:(?:watch)?\?v(?:i)?=|\&v(?:i)?=))([^#\&\?]*).*/);
                if(ytMatch && ytMatch[1]) vid = ytMatch[1];
            }

            if(vid) {
                if(isVimeo) {
                    player.src = "https://player.vimeo.com/video/" + vid + "?autoplay=1&title=0&byline=0&portrait=0";
                } else {
                    // Rel=0 reduces suggested videos, fs=0 hides native fullscreen button, enablejsapi=1 for speed control
                    player.src = "https://www.youtube.com/embed/" + vid + "?rel=0&autoplay=1&modestbranding=1&fs=0&enablejsapi=1";
                }
            } else {
                player.src = "";
            }

        } else {
             player.style.display = 'none';
             player.src = ""; // Stop video
             ph.classList.remove('d-none');

             const ab = document.getElementById('actionButton');
             const pt = document.getElementById('placeholderTitle');
             const pm = document.getElementById('placeholderMsg');

             if(type === 'live_class') {
                 pt.innerText = "Live Session";
                 pm.innerText = "Join via Zoom";
                 ab.classList.remove('d-none');
                 ab.href = url || '#';
             } else {
                 pt.innerText = "Document";
                 pm.innerText = "Download file";
                 ab.classList.add('d-none');
             }
        }
    }

    function changeVideoSpeed(speed) {
        const playerFrame = document.getElementById('mainPlayer');
        const url = playerFrame.src;
        const speedVal = parseFloat(speed);

        if(!url) return;

        // 1. YouTube Speed Control
        if (url.includes('youtube.com')) {
            // Try PostMessage (Works for raw iframe with enablejsapi=1)
            playerFrame.contentWindow.postMessage(JSON.stringify({
                'event': 'command',
                'func': 'setPlaybackRate',
                'args': [speedVal]
            }), '*');
        } 
        else if (url.includes('vimeo.com')) {
            const data = {
                method: 'setPlaybackRate',
                value: speedVal
            };
            playerFrame.contentWindow.postMessage(JSON.stringify(data), '*');
        }
    }

    // --- Advanced Security Measures (User Requested) ---

    // 1. Screen Recording / Sharing Detection
    if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
        setInterval(async () => {
            try {
                if (navigator.mediaDevices.displayMedia) {
                     const p = document.getElementById('mainPlayer');
                     if(p) p.style.display = 'none';
                     alert("Screen Recording detected! Video paused.");
                }
            } catch (err) {}
        }, 3000);
    }

    // 2. Anti-Screenshot (PrintScreen Key)
    document.addEventListener('keyup', (e) => {
        if (e.key === 'PrintScreen') {
            navigator.clipboard.writeText(''); // Clear clipboard
            alert('Screenshots are disabled on this page.');
        }
    });

    // 3. Blur/Focus Protection (Hide video when tab is not active)
    window.addEventListener('blur', () => {
        const p = document.getElementById('mainPlayer');
        if(p) p.style.opacity = '0';
    });
    
    window.addEventListener('focus', () => {
        const p = document.getElementById('mainPlayer');
        if(p) p.style.opacity = '1';
    });
</script>
@endsection
