@extends('layouts.student')

@section('content')
<h2 class="mb-4">Browsing All Courses</h2>

<div class="row">
    @forelse($courses as $course)
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            @if($course->thumbnail)
                <img src="{{ asset('storage/' . $course->thumbnail) }}" class="card-img-top" alt="{{ $course->title }}" style="height: 200px; object-fit: cover;">
            @else
                <div class="card-img-top bg-secondary text-white d-flex align-items-center justify-content-center" style="height: 200px;">
                    <span class="fs-1">Course</span>
                </div>
            @endif
            <div class="card-body d-flex flex-column">
                <h5 class="card-title">{{ $course->title }}</h5>
                <p class="card-text text-muted small">{{ Str::limit($course->description, 100) }}</p>
                <div class="mt-auto d-flex justify-content-between align-items-center">
                    <span class="fw-bold text-primary">{{ $course->price > 0 ? 'LKR '.number_format($course->price, 2) : 'Free' }}</span>
                    <a href="{{ route('student.courses.show', $course) }}" class="btn btn-outline-primary btn-sm">View Details</a>
                </div>
            </div>
        </div>
    </div>
    @empty
    <div class="col-12">
        <div class="alert alert-info py-5 text-center">
            <h3>No courses available yet.</h3>
            <p>Please check back later.</p>
        </div>
    </div>
    @endforelse
</div>

{{ $courses->links() }}
@endsection
